<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "steam";

    $conn = mysqli_connect($server, $username, $password, $database);
?>
